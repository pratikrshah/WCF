﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Collections;
using System.Runtime.Serialization;

using Bloomberglp.Blpapi;

namespace MarketFeedServiceLibrary
{
    [ServiceContract(CallbackContract = typeof(IBloombergServiceCallback), SessionMode = SessionMode.Required)]    
    interface IBloombergService
    {
        [OperationContract(IsOneWay = true)]
        //[FaultContract(typeof(MyFaultException))]
        void StartSubscription(int interval, ArrayList securityList, ArrayList fieldList);

        [OperationContract(IsOneWay = true)]
        void StopSubscription();
        
        [OperationContract(IsOneWay = true)]
        void TestFireMultiply(int result);

        [OperationContract]
        void IsMarketSimulator(bool val);
    }

    public interface IBloombergServiceCallback
    {
        [OperationContract(IsOneWay = true)]
        void UpdateStatus(string message);

        [OperationContract(IsOneWay = true)]
        void UpdateBloombergData(Dictionary<string, string> bDataList);
    }

    [DataContract]
    public class BloombergException
    {
        [DataMember]
        public string Operation;

        [DataMember]
        public string Reason;

        [DataMember]
        public string Details;
    }

    [DataContract]
    public class MyFaultException
    {
        private string _reason;

        [DataMember]
        public string Reason
        {
            get { return _reason; }
            set { _reason = value; }
        }
    }


}
