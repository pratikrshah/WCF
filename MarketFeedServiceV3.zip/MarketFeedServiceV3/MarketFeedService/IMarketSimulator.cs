﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Collections;

namespace MarketFeedServiceLibrary
{
    [ServiceContract(CallbackContract = typeof(IMarketSimulatorCallback), SessionMode = SessionMode.Required)]    
    interface IMarketSimulator
    {
        [OperationContract(IsOneWay = true)]        
        void StartSubscription(int interval, ArrayList securityList, ArrayList fieldList);

        [OperationContract(IsOneWay = true)]
        void StopSubscription();
    }

    public interface IMarketSimulatorCallback
    {
        [OperationContract(IsOneWay = true)]
        void UpdateStatus(string message);

        [OperationContract(IsOneWay = true)]
        void UpdateBloombergData(Dictionary<string, string> bDataList);
    }
}
