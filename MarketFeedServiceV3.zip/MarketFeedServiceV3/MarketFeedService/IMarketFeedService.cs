﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace MarketFeedServiceLibrary
{
    [ServiceContract]
    public interface IMarketFeedService
    {
        [OperationContract]
        List<Customer> ListCustomer();
    }
                                                                                
    [DataContract]
    public class Customer
    {
        [DataMember]
        public string CustomerId { get; set; }

        [DataMember]
        public string CompanyName { get; set; }
    }
}
