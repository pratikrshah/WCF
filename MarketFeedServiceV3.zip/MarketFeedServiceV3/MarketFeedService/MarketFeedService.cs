﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace MarketFeedServiceLibrary          
{
    public class MarketFeedService: IMarketFeedService
    {
        #region IMarketFeedService Members

        private Customer customer = null;
        private List<Customer> customers = null;

        public List<Customer> ListCustomer()
        {
            customers = new List<Customer>();                
            using (var cnn = new SqlConnection("aaaa"))
            {
                using (var cmd = new SqlCommand("Select CustomerId, CompanyName from Customers Order by CustomerID", cnn))
                {
                    cnn.Open();
                    using (SqlDataReader CustomersReader = cmd.ExecuteReader())
                    {
                        while (CustomersReader.Read())
                        {
                            customer = new Customer();
                            customer.CustomerId = CustomersReader.GetString(0);
                            customer.CompanyName = CustomersReader.GetString(1);
                            customers.Add(customer);
                        }
                    }
                }
            }
            return customers;
        }

        #endregion
    }
}
