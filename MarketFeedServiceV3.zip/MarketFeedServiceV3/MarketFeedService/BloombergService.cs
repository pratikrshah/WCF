﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Collections;
using System.Data;
using System.Timers;

using Event = Bloomberglp.Blpapi.Event;
using Message = Bloomberglp.Blpapi.Message;
using Element = Bloomberglp.Blpapi.Element;
using Name = Bloomberglp.Blpapi.Name;
using Request = Bloomberglp.Blpapi.Request;
using Service = Bloomberglp.Blpapi.Service;
using Session = Bloomberglp.Blpapi.Session;
using SessionOptions = Bloomberglp.Blpapi.SessionOptions;
using EventHandler = Bloomberglp.Blpapi.EventHandler;
using CorrelationID = Bloomberglp.Blpapi.CorrelationID;
using Subscription = Bloomberglp.Blpapi.Subscription;
using Bloomberglp.Blpapi;


namespace MarketFeedServiceLibrary
{
    //[ServiceBehavior(InstanceContextMode = InstanceContextMode.Single, ConcurrencyMode = ConcurrencyMode.Reentrant)]
    public class BloombergService : IBloombergService
    {
        #region Private Variables
        private static readonly Name EXCEPTIONS = new Name("exceptions");
        private static readonly Name FIELD_ID = new Name("fieldId");
        private static readonly Name REASON = new Name("reason");
        private static readonly Name CATEGORY = new Name("category");
        private static readonly Name DESCRIPTION = new Name("description");
        private static readonly Name ERROR_CODE = new Name("errorCode");
        private static readonly Name SOURCE = new Name("source");
        private static readonly Name SECURITY_ERROR = new Name("securityError");
        private static readonly Name MESSAGE = new Name("message");
        private static readonly Name RESPONSE_ERROR = new Name("responseError");
        private static readonly Name SECURITY_DATA = new Name("securityData");
        private static readonly Name FIELD_EXCEPTIONS = new Name("fieldExceptions");
        private static readonly Name ERROR_INFO = new Name("errorInfo");

        private Session d_session;
        private List<Subscription> d_subscriptions = new List<Subscription>();
        private List<CorrelationID> d_correlationIDs = new List<CorrelationID>();
        private ArrayList d_securities = new ArrayList();

        private List<Subscription> tempsub = new List<Subscription>();

        private ArrayList d_ToRemoveList = new ArrayList();
        private List<CorrelationID> d_Remove_correlationIDs = new List<CorrelationID>();

        private ArrayList d_ToAddList = new ArrayList();
        private List<Subscription> d_AddSubscriptions = new List<Subscription>();

        private DataSet dsTickers;

        List<string> fields = new List<string>();
        List<string> options = new List<string>();
        private Boolean d_isSubscribed = false;
        private Hashtable ReturnInfo = new Hashtable();
        private Hashtable _htRRData = new Hashtable();
        private int _interval;
        private bool _issimulator;
        private ArrayList _securitylist;
        private ArrayList _fieldlist;
        private IBloombergServiceCallback callback;
        private Dictionary<string, string> _datalist = new Dictionary<string,string>();
        private Timer SimulatorTimer = new Timer();
        #endregion

        #region Properties
        public int Interval
        {
            get { return _interval; }
            set { _interval = value; }
        }

        public bool IsSimulator
        {
            get { return _issimulator; }
            set { _issimulator = value; }
        }

        public ArrayList SecurityList
        {
            get { return _securitylist; }
            set { _securitylist = value; }
        }

        public ArrayList FieldList
        {
            get { return _fieldlist; }
            set { _fieldlist = value; }
        }
        #endregion

        #region IBloombergService Members

        public BloombergService()
        {
            this.IsSimulator = false;
        }

        public BloombergService(bool simulator)
        {
            this.IsSimulator = simulator;
        }

        public void IsMarketSimulator(bool val)
        {
            this.IsSimulator = val;
        }

        public void StartSubscription(int interval, System.Collections.ArrayList securityList, ArrayList fieldList)
        {   
            try
            {   
                callback = OperationContext.Current.GetCallbackChannel<IBloombergServiceCallback>();
                this.SecurityList = securityList;
                this.FieldList = fieldList;

                if (this.IsSimulator) // Run Market Simulator
                {
                    SimulatorTimer.Elapsed += new ElapsedEventHandler(RunSimulatorEvent);
                    SimulatorTimer.Interval = (interval == 0) ? 500 : interval * 1000;
                    SimulatorTimer.Start();
                    this.UpdateStatus("Starting Market Simulator...");
                }
                else
                {
                    this.Interval = interval;
                    d_securities = securityList;
                    fields.Clear(); options.Clear(); d_subscriptions.Clear(); d_correlationIDs.Clear();

                    // create session
                    if (!createSession())
                    {
                        UpdateStatus("Failed to start session.");
                        return;
                    }
                    // open market data service
                    if (!d_session.OpenService("//blp/mktdata"))
                    {
                        UpdateStatus("Failed to open //blp/mktdata");
                        return;
                    }
                    UpdateStatus("Connected sucessfully");
                    Service refDataService = d_session.GetService("//blp/mktdata");

                    AddSecuritiesAndFieldsToArrayList(fieldList);

                    // subscribe to securities
                    d_session.Subscribe(d_subscriptions);
                    d_isSubscribed = true;
                    UpdateStatus("Subscribed to securities...");
                }
            }
            catch (Exception exp)
            {
                // Log exception
                UpdateStatus("SrvErr: " + exp.Message);
                //MyFaultException theFault = new MyFaultException();
                //theFault.Reason = "Some Error " + exp.Message.ToString();
                //throw new FaultException<MyFaultException>(theFault);
            }

        }

        public void StopSubscription()
        {
            try
            {
                if (this.IsSimulator)
                {
                    SimulatorTimer.Stop();
                    this.UpdateStatus("Market Simulator stopped");
                }
                else
                {
                    if (d_subscriptions != null && d_isSubscribed)
                    {
                        for (int i = 0; i < d_subscriptions.Count; i++)
                            d_correlationIDs.Add(d_subscriptions[i].CorrelationID);
                        d_session.Cancel(d_correlationIDs);

                        //d_session.Unsubscribe(d_subscriptions);
                        UpdateStatus("Subscription stopped");
                    }
                    d_isSubscribed = false;
                }
            }
            catch (Exception ex)
            {
                UpdateStatus(ex.Message);
            }
        }

        public void RunSimulatorEvent(object source, ElapsedEventArgs e)
        {
            _datalist.Clear();

            int idx;
            Random ranNum = new Random();
            
            try
            {
                idx = ranNum.Next(0, Convert.ToInt16(SecurityList.Count * 0.9));
            }
            catch
            {
                idx = 0;
            }
            _datalist.Add("TICKER", this.SecurityList[idx].ToString());

            for (int i = 0; i < this.FieldList.Count; i++)
            { 
                if (this.FieldList[i].ToString().Equals("VOLUME"))
                    _datalist.Add(this.FieldList[i].ToString(), Convert.ToString(ranNum.Next(1000*2+3, 300000*2+7)));
                else
                    _datalist.Add(this.FieldList[i].ToString(), Convert.ToString(new Random().Next(0, 110*2+3)));
            }
            UpdateBloombergData(_datalist);
        }

        public void TestFireMultiply(int result)
        {
            IBloombergServiceCallback callbackaa = OperationContext.Current.GetCallbackChannel<IBloombergServiceCallback>();
            System.Threading.Thread.Sleep(new TimeSpan(0, 0, 3));
            callbackaa.UpdateStatus(Convert.ToString(result*result));
        }

        #endregion

        #region Private Methods

        private bool createSession()
        {
            if (d_session == null)
            {
                UpdateStatus("Connecting...");
                d_session = new Session(new SessionOptions(), new EventHandler(processEvent));
            }
            return d_session.Start();
        }        

        private void AddSecuritiesAndFieldsToArrayList(ArrayList fieldList)
        {
            // TEMPORARY METHOD FOR TESTING

            // Create Options
            options.Add("interval=" + this.Interval);

            // Create FieldList
            for (int i = 0; i < fieldList.Count; i++)
                fields.Add(fieldList[i].ToString());

            // Create ArrayList of Securities             
            for (int i = 0; i < d_securities.Count; i++)
            {
                d_subscriptions.Add(new Subscription(d_securities[i].ToString(),
                                                     fields,
                                                     options,
                                                     new CorrelationID(i)));
            }
        }

        private void UpdateStatus(string msg)
        {
            UpdateStatus(msg, string.Empty);            
        }

        private void UpdateStatus(string msg, string source)
        {         
            callback.UpdateStatus(msg);
        }

        private void UpdateBloombergData(Dictionary<string,string> _list)
        {
            callback.UpdateBloombergData(_list);
        }

        #region Bloomberg API Events

        public void processEvent(Event eventObj, Session session)
        {   
            try
            {
                switch (eventObj.Type)
                {
                    case Event.EventType.SUBSCRIPTION_DATA:
                        // process subscription data
                        processRequestDataEvent(eventObj, session);
                        break;
                    case Event.EventType.SUBSCRIPTION_STATUS:
                        // process subscription status
                        processRequestStatusEvent(eventObj, session);
                        break;
                    case Event.EventType.PARTIAL_RESPONSE:
                        // process request/response partial response
                        processResponseEvent(eventObj);
                        break;
                    case Event.EventType.RESPONSE:
                        // process request/response final response
                        processResponseEvent(eventObj);
                        break;
                    default:
                        processMiscEvents(eventObj, session);
                        break;
                }
            }
            catch (System.Exception ex)
            {   
                UpdateStatus("Exceptiona " + ex.Message.ToString());
            }
        }

        private void processRequestDataEvent(Event eventObj, Session session)
        {     
            foreach (Message msg in eventObj.GetMessages())
            {
                string topic = (string)msg.TopicName;
                _datalist.Clear();
                _datalist.Add("TICKER", topic.Trim());
                
                // Loop through each the list to check if it matches our fields
                for (int i = 0; i < fields.Count; i++)
                {
                    if (msg.HasElement(fields[i]))
                    {
                        // check element to see if it has null value
                        if (!msg.GetElement(fields[i]).IsNull)
                        {
                            // Get the Data and pass to UI to populate Grid
                            _datalist.Add(fields[i], msg.GetElementAsString(fields[i]));
                        }
                    }
                }
                UpdateBloombergData(_datalist);
                //UpdateStatus(msg.CorrelationID.Value.ToString() + " Processed Security: " + msg.TopicName + " *** LAST_PRICE:" + ReturnInfo["LAST_PRICE"].ToString(), "GOODSEC");
                
                //if (ReturnInfo.Count > 1) // Update DB only if Bloomberg returns value for ATLEAST one field for the security
                //    ApplicationTier.PricingManagement.InsertIntoDB(ReturnInfo);
            }
        }

        private void processRequestStatusEvent(Event eventObj, Session session)
        {
            foreach (Message msg in eventObj.GetMessages())
            {
                string topic = (string)msg.TopicName;
                if (msg.HasElement(REASON))
                {
                    Element reason = msg.GetElement(REASON); // This can occur on SubscriptionFailure.

                    if (reason.GetElement(DESCRIPTION).GetValueAsString() != "Subscription canceled")
                    {
                        //Create a list of Bad Security and Update DB
                        //PricingManagement.InsertBadSecurityIntoDB(topic, reason.GetElement(CATEGORY).GetValueAsString() + ": "
                        //                                               + reason.GetElement(DESCRIPTION).GetValueAsString());
                        UpdateStatus(msg.TopicName + " : " + reason.GetElement(CATEGORY).GetValueAsString() + " : "
                                                           + reason.GetElement(DESCRIPTION).GetValueAsString(), "BADSEC");
                    }
                }

                if (msg.HasElement(EXCEPTIONS))
                {
                    // This can occur on SubscriptionStarted if at least one field is good while the rest are bad.
                    Element exceptions = msg.GetElement(EXCEPTIONS);
                    for (int i = 0; i < exceptions.NumValues; ++i)
                    {
                        Element exInfo = exceptions.GetValueAsElement(i);
                        Element fieldId = exInfo.GetElement(FIELD_ID);
                        Element reason = exInfo.GetElement(REASON);
                        UpdateStatus("bb " + fieldId.GetValueAsString() + ": " + reason.GetElement(CATEGORY).GetValueAsString());
                    }
                }
            }
        }

        private void processMiscEvents(Event eventObj, Session session)
        {
            foreach (Message msg in eventObj.GetMessages())
            {
                switch (msg.MessageType.ToString())
                {
                    case "RequestFailure":
                        Element reason = msg.GetElement(REASON);
                        string message = string.Concat("Error: Source-", reason.GetElementAsString(SOURCE),
                            ", Code-", reason.GetElementAsString(ERROR_CODE), ", category-", reason.GetElementAsString(CATEGORY),
                            ", desc-", reason.GetElementAsString(DESCRIPTION));
                        UpdateStatus("zz " + message);
                        break;
                    default:
                        UpdateStatus(msg.MessageType.ToString() + " " + msg.TopicName);
                        break;
                }
            }
        }

        private void sendRefDataRequest(Session session, ArrayList securityNonCurrentList)
        {
            Service refDataService = session.GetService("//blp/refdata");
            Request request = refDataService.CreateRequest("ReferenceDataRequest");
            Element securities = request.GetElement("securities");
            for (int i = 0; i < securityNonCurrentList.Count; ++i)
            {
                securities.AppendValue((string)securityNonCurrentList[i]);
            }
            Element efields = request.GetElement("fields");

            for (int i = 0; i < fields.Count; ++i)
            {
                efields.AppendValue((string)fields[i]);
            }
            session.SendRequest(request, null);
        }

        private void processResponseEvent(Event eventObj)
        {
            DataRow tickerInfo;
            foreach (Message msg in eventObj.GetMessages())
            {

                if (msg.HasElement("responseError"))
                {
                    UpdateStatus("RR Request failed: " + msg.GetElement("responseError"));
                    continue;
                }

                Element securities = msg.GetElement("securityData");
                int numSecurities = securities.NumValues;
                for (int i = 0; i < numSecurities; ++i)
                {
                    Element security = securities.GetValueAsElement(i);
                    string ticker = security.GetElementAsString("security");
                    if (security.HasElement("securityError"))
                    {
                        Element securityError = security.GetElement("securityError");
                        UpdateStatus("RR--" + ticker + " " + securityError.GetElementAsString("category") + " " + securityError.GetElementAsString("message"), "RRBADSEC");
                        //Create a list of Bad Security and Update DB
                        //PricingManagement.InsertBadSecurityIntoDB(ticker, securityError.GetElementAsString("category") + ": " + securityError.GetElementAsString("message"));
                        continue;
                    }

                    _htRRData.Clear();
                    _htRRData.Add("id_ticker_exch", ticker.Trim());
                    //tickerInfo = GetTickerInfo(ticker);
                    //if (tickerInfo != null)
                    //{
                    //    _htRRData.Add("id_ticker", tickerInfo["id_ticker"].ToString());
                    //    _htRRData.Add("id_type", tickerInfo["id_type"].ToString());
                    //}


                    Element fields = security.GetElement("fieldData");
                    if (fields.NumElements > 0)
                    {
                        int numElements = fields.NumElements;
                        for (int j = 0; j < numElements; ++j)
                        {
                            Element field = fields.GetElement(j);
                            // Create a Hashtable for with field values for each security
                            _htRRData.Add(field.Name, field.GetValueAsString());
                        }
                        UpdateStatus(msg.CorrelationID.Value.ToString() + " RR Processed Security: " + ticker, "RRGOODSEC");
                        //if (_htRRData.Count > 1) // Update DB only if Bloomberg returns value for ATLEAST one field for the security
                        //    ApplicationTier.PricingManagement.InsertIntoDB(_htRRData);
                    }

                    Element fieldExceptions = security.GetElement("fieldExceptions");
                    if (fieldExceptions.NumValues > 0)
                    {
                        for (int k = 0; k < fieldExceptions.NumValues; ++k)
                        {
                            Element fieldException = fieldExceptions.GetValueAsElement(k);
                            UpdateStatus(fieldException.GetElementAsString("fieldId") + " " + fieldException.GetElement("errorInfo"));
                        }
                    }
                }
            }
        }

        #endregion

        #endregion

        
    }

    
}
