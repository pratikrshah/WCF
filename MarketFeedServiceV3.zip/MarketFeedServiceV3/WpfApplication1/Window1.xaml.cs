﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Collections;
using System.Threading;
using System.ServiceModel;
using WpfApplication1.BloombergServiceReference;
using Microsoft.Windows.Controls;
using System.Reflection;


namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public DataSet _bData;
        public BloombergDataCallBack callback;
        public InstanceContext context;
        public BloombergServiceClient proxy = null;

        delegate void SetControlValueCallback(Control oControl, string propName, object propValue);
        delegate void VoidMethodDelegate();
        delegate void StringMethodDelegate(string val);
        private Dictionary<string, string> _dataList = new Dictionary<string, string>();
        private ArrayList securityList = new ArrayList();
        private ArrayList FieldsList = new ArrayList();
        private Style redStyle;
        private Style greenStyle;
        private Microsoft.Windows.Controls.DataGridRow dataGridRows;

        private void CreateTickerList()
        {
            securityList.Clear();
            string tickers = string.Empty;
            
            if (!(bool)chkTest.IsChecked)
                tickers = "IBM US Equity, MSFT US Equity,GOOG US Equity,INTC US Equity,ORCL US Equity,PFE US Equity";
            else
            //    tickers = txtTickers.Text;
            tickers = "CH Equity,A US Equity,A2A IM Equity,AA US Equity,AABAR UH Equity,AACC US Equity,AAI US Equity,AAL LN Equity,AAPL US Equity,AAV CN Equity,AB1 GR Equity,AB1 GY Equity,ABB US Equity,ABBN VX Equity,ABC US Equity,ABD US Equity,ABG SM Equity,ABG US Equity,ABG 12 P23 Equity,ABK US Equity,ABT US Equity,ABX CN Equity,ABX US Equity,AC FP Equity,AC/A CN Equity,ACA FP Equity,ACE LN Equity,ACE US Equity,ACE+NL Equity,ACE+OL Equity,ACE/A CN Equity,ACF US Equity,ACGL US Equity,ACH US Equity,ACI US Equity,ACL US Equity,ACL+AH Equity,ACLS US Equity,ACPI US Equity,ACS+MH Equity,ACS+WH Equity,ACUS US Equity,ACXM US Equity,ACY NO Equity,ADCT US Equity,ADEN VX Equity,ADI US Equity,ADI+AY Equity,ADI+GF Equity,ADI+MX Equity,ADI+MY Equity,ADM US Equity,ADN LN Equity,ADP US Equity,ADPT US Equity,ADS GR Equity,ADS US Equity,AED Curncy,AEE US Equity,AEG SJ Equity,AEIS US Equity,AEL US Equity,AEM US Equity,AEP US Equity,AEPI US Equity,AERG US Equity,AES US Equity,AET US Equity,AF FP Equity,AFFX US Equity,AFG US Equity,AFID LI Equity,AFN CN Equity,AG-U CN Equity,AGA CN Equity,AGCO US Equity,AGEN US Equity,AGI CN Equity,AGI NO Equity,AGL IM Equity,AGL US Equity,AGN NA Equity,AGN US Equity,AGO US Equity,AGO+ME Equity,AGP US Equity,AGS LN Equity,AGYS US Equity,AHC US Equity,AHL US Equity,AHT GB Equity,AI FP Equity,AIG US Equity,AIG+QZ Equity,AIN US Equity,AIQ US Equity,AIR US Equity,AIZ US Equity,AJL+LV Equity,AJL+WV Equity,AJL+XV Equity,AKAM US Equity,AKR US Equity,AKS NO Equity,AKS US Equity,AKZA NA Equity,ALA-U CN Equity,ALBAV FH Equity,ALBK ID Equity,ALDAR UH Equity,ALF NZ Equity,ALK US Equity,ALKS US Equity,ALL US Equity,ALLN SW Equity,ALN US Equity,ALNBT FP Equity,ALOY US Equity,ALPRO FP Equity,ALSK US Equity,ALT FP Equity,ALU FP Equity,ALU US Equity,ALV GR Equity,ALV US Equity,ALXN US Equity,ALY US Equity,AM US Equity,AMCN US Equity,AMD US Equity,AMD+AA Equity,AMEC LN Equity,AMG US Equity,AMGN US Equity,AMIE US Equity,AMKR US Equity,AMLN US Equity,AMMD US Equity,AMQ+GJ Equity,AMQ+JJ Equity,AMR US Equity,AMS US Equity,AMT US Equity,AMZN US Equity,AN US Equity,AN+AV Equity,ANAD US Equity,ANF US Equity,ANG SJ Equity,ANH US Equity,ANN US Equity,ANO CN Equity,ANR US Equity,ANZ NZ Equity,AOB US Equity,AOI US Equity,AOIL SS Equity,APC US Equity,APOL US Equity,APU US Equity,APV+FJ Equity,APV+UN Equity,APV+VL Equity,APV+VN Equity,APV+WO Equity,APV+WP Equity,APWR US Equity,AQN CN Equity,AQP LN Equity,AQP SJ Equity,ARE CN Equity,ARE US Equity,ARE+JJ Equity,ARG US Equity,ARM US Equity,ARO GR Equity,ARRS US Equity,ARTC US Equity,ARW US Equity,ASA SJ Equity,ASCA US Equity,ASM NA Equity,ASMI US Equity,ASML NA Equity,ASML US Equity,ASX US Equity,ATA FP Equity,ATEC AV Equity,ATI US Equity,ATK US Equity,ATLN VX Equity,ATMI US Equity,ATML US Equity,ATO FP Equity,ATP CN Equity,ATPG US Equity,ATS Curncy,ATSI US Equity,ATU US Equity,AU CN Equity,AU US Equity,AUB FP Equity,AUD Curncy,AUDC US Equity,AUO US Equity,AURE FP Equity,AUY US Equity,AUY+GB Equity,AUY+GH Equity,AV US Equity,AV/ LN Equity,AVA US Equity,AVB US Equity,AVB+MR Equity,AVP US Equity,AVP US 1 C40 Equity,AVP US 1 P40 Equity,AVT US Equity,AVTR US Equity,AVY US Equity,AWI US Equity,AX-U CN Equity,AXE US Equity,AXL US Equity,AXP US Equity,AYE US Equity,AZN LN Equity,AZO US Equity,AZPN US Equity,B US Equity,B2I GR Equity,BA US Equity,BA/ LN Equity,BAC US Equity,BALN VX Equity,BAMA NA Equity,BANPU TB Equity,BARC LN Equity,BAS GR Equity,BAW SJ Equity,BAX US Equity,BAY LN Equity,BBA LN Equity,BBBB US Equity,BBD/B CN Equity,BBDC3 BZ Equity,BBG US Equity,BBI US Equity,BBVA SM Equity,BBY US Equity,BC US Equity,BCB CN Equity,BCI PM Equity,BCP PL Equity,BDC US Equity,BDK US Equity,BDN US Equity,BDTTZ US Equity,BDU+CB Equity,BDX US Equity,BDX+KO Equity,BDX+LO Equity,BEAT US Equity,BEAV US Equity,BEC US Equity,BEE US Equity,BEF Curncy,BEI GR Equity,BELM US Equity,BEN US Equity,BESI NA Equity,BG US Equity,BGC CN Equity,BGC US Equity,BGG US Equity,BGH TB Equity,BGY GB Equity,BHI US Equity,BHP US Equity,BHW PW Equity,BID US Equity,BIDU US Equity,BIIB US Equity,BIM IM Equity,BIO US Equity,BJN+XA Equity,BJS US Equity,BKI US Equity,BKMB OM Equity,BKS US Equity,BKUNQ US Equity,BLAND TB Equity,BLDR US Equity,BLK US Equity,BLL US Equity,BLND LN Equity,BLT LN Equity,BLT US Equity,BMC US Equity,BMD CN Equity,BMPS IM Equity,BMPS 12 C1.25 Equity,BMPS 12 C1.40 Equity,BMPS 12 C1.55 Equity,BMPS 12 P1.10 Equity,BMPS 12 P1.15 Equity,BMPS 12 P1.20 Equity,BMPS 12 P1.35 Equity,BMPS 12 P1.40 Equity,BMPS 12 P1.65 Equity,BMPS 3 C1.90 Equity,BMPS 3 P1.30 Equity,BMPS 3 P1.90 Equity,BMPS 4 P1.00 Equity,BMPS 6 C1.80 Equity,BMPS 6 C1.90 Equity,BMPS 6 P.90 Equity,BMPS 6 P1.15 Equity,BMPS 6 P1.90 Equity,BMPS 9 C1.20 Equity,BMPS 9 C1.25 Equity,BMPS 9 P1.05 Equity,BMPS 9 P1.15 Equity,BMPS 9 P1.20 Equity,BMPS IM 2 C1.25 Equity,BMPS IM 3 C1.35 Equity,BMPS IM 6 C1.25 Equity,BMPS IM 6 C1.35 Equity,BMPS IM 6 C1.40 Equity,BMPS IM 6 P1.40 Equity,BMPS IM 6 P1.80 Equity,BMPS IM 9 C1.25 Equity,BMPS IM 9 C1.30 Equity,BMPS IM 9 C1.35 Equity,BMR US Equity,BMRN US Equity,BMS US Equity,BMW GR Equity,BMY US Equity,BN FP Equity,BNE US Equity,BNI+LP Equity,BNP FP Equity,BNP-U CN Equity,BNQ+JD Equity,BNS IM Equity,BOC GA Equity,BONT US Equity,BP IM Equity,BP US Equity,BP/ LN Equity,BPA LN 3 C600 Equity,BPA LN 3 P520 Equity,BPA LN 3 P720 Equity,BPA LN 9 C680 Equity";//,BPA LN 9 P680 Equity,BPC CN Equity,BPE IM Equity,BPFH US Equity,BPO CN Equity,BRCD US Equity,BRCM US Equity,BRE US Equity,BRE-U CN Equity,BREB BB Equity,BRK-U CN Equity,BRK/B US Equity,BRKS US Equity,BRL Curncy,BRLUSD Curncy,BRS US Equity,BRTS IT Equity,BSC US Equity,BSKT US Equity,BSX US Equity,BSY LN Equity,BTE-U CN Equity,BTU US Equity,BTU+SN Equity,BTX GB Equity,BUD US Equity,BUL IM Equity,BUL IM 12 P6.60 Equity,BULL FP Equity,BVF US Equity,BVN US Equity,BWA US Equity,BWS US Equity,BXC US Equity,BXE CN Equity,BXG US Equity,BXP US Equity,BYD US Equity,BYO+AN Equity,BYO+AO Equity,BYO+AP Equity";

            securityList.AddRange(tickers.Split(new char[] { ',' }));
            for (int i = 0; i < securityList.Count; i++)
                securityList[i] = securityList[i].ToString().Trim();

            ArrayList temp = new ArrayList();
            temp = ShuffleArrayList(securityList);
            securityList.Clear();
            securityList = temp;

        }

        private ArrayList ShuffleArrayList(ArrayList source)
        {
            ArrayList sortedList = new ArrayList();
            Random generator = new Random();

            while (source.Count > 0)
            {
                int position = generator.Next(source.Count);
                sortedList.Add(source[position]);
                source.RemoveAt(position);
            }

            return sortedList;
        }

        private void BindData()
        {
            try
            {   
                if (dataGrid1.Dispatcher.Thread != Thread.CurrentThread)
                {
                    Dispatcher.BeginInvoke(new VoidMethodDelegate(BindData));
                    return;
                }


                int i = 0; object aaa;                
                foreach (DataRow row in _bData.Tables[0].Rows)
                {
                    if (_dataList.ContainsValue(row["TICKER"].ToString()))
                    {
                        foreach (KeyValuePair<string, string> pair in _dataList)
                        {
                            if (pair.Key.Equals("LAST_PRICE") && row[pair.Key] != DBNull.Value)
                            {
                                //aaa = dataGrid1.Items.GetItemAt(i) as DataGridRow;

                                //if (Convert.ToDouble(row[pair.Key]) < Convert.ToDouble(pair.Value))
                                //    dataGrid1.RowStyle = greenStyle;                                
                                //else
                                //    dataGrid1.RowStyle = redStyle;                                
                            }
                            row[pair.Key] = pair.Value;
                        }                        
                        break;
                    }
                    i++;
                }                
            }
            catch (Exception ex)
            {
                //textBox1.Text += ex.Message + Environment.NewLine;
            }
        }

        private void callback_UpdateReceived_eventHandler(object sender, EventArgs e)
        {
            BloombergEventArgs args = (BloombergEventArgs)e;
            if (args.Source == SourceReceived.StatusReceived)
            {
                UpdateTextBlock(textBlock1.Text + DateTime.Now + " - " + args.Message + Environment.NewLine);
                //SetControlPropertyValue(textBlock1, "Text", textBlock1.Text + DateTime.Now + " - " + args.Message + Environment.NewLine);
            }
            else if (args.Source == SourceReceived.DataReceived)
            {
                _dataList = args.DataList;
                BindData();
            }
        }

        private void UpdateTextBlock(string val)
        {
            if (textBlock1.Dispatcher.Thread != Thread.CurrentThread)
            {
                textBlock1.Dispatcher.BeginInvoke(new StringMethodDelegate(UpdateTextBlock), new object[] { val });
                return;
            }

            textBlock1.Text = val;
        }
        
        private void CreateStructure()
        {
            _bData = new DataSet();
            DataTable dt = new DataTable();
            dt.Columns.Add("TICKER", typeof(string));
            for (int i = 0; i < FieldsList.Count; i++)
                dt.Columns.Add(FieldsList[i].ToString(), typeof(string));
            dt.Columns.Add("CustomComments", typeof(string));

            for (int i = 0; i < securityList.Count; i++)
            {
                object[] rowVals = new object[FieldsList.Count];
                rowVals[0] = securityList[i].ToString();
                dt.Rows.Add(rowVals);
            }
            
            _bData.Tables.Add(dt);
        }

        public Window1()
        {
            InitializeComponent();

            redStyle = this.FindResource("StockLossRowStyle") as Style;
            greenStyle = this.FindResource("StockProfitRowStyle") as Style;

            #region Creating DataTable
            DataTable dt = new DataTable();
            dt.Columns.Add("Ticker", typeof(string));
            dt.Columns.Add("MarketValue", typeof(string));
            dt.Columns.Add("MarketValue (T-1)", typeof(string));
            //dt.Rows.Add("AMIT Equity", "840", "1100");
            //dt.Rows.Add("TED US Equity", "333", "566");
            //dt.Rows.Add("WHATEVER US Equity", "840", "1100");
            //dt.Rows.Add("BlAHBLAH US Equity", "840", "1100");
            //dt.Rows.Add("ELEVEN US Equity", "333", "6755");
            //dt.Rows.Add("TWELVE US Equity", "840", "1100");
            #endregion

            #region On Load
            string strFieldName = "LAST_PRICE,BID,ASK,PREV_CLOSE_VALUE_REALTIME,VOLUME";
            FieldsList.AddRange(strFieldName.Split(new char[] { ',' }));
           
            callback = new BloombergDataCallBack();
            context = new InstanceContext(callback);
            proxy = new BloombergServiceClient(context);
            proxy.IsMarketSimulator(true);

            if (callback != null)
                callback.UpdateReceived += new BloombergDataCallBack.BloombergEventHandler(callback_UpdateReceived_eventHandler);
            #endregion

           

            

        }

        private void DataGrid_RowEditEnding(object sender, DataGridRowEditEndingEventArgs e)
        {
            // drill down from DataGridRow, through row view to our order row
            DataGridRow dgRow = e.Row;
            DataRowView rowView = dgRow.Item as DataRowView;
            
            //NorthwindDataSet.OrdersRow orderRow = rowView.Row as NorthwindDataSet.OrdersRow;

            // set the foreign key to the customer ID
            //orderRow.CustomerID = CustomerGrid.SelectedValue as string;
        }

        public IEnumerable<Microsoft.Windows.Controls.DataGridRow> GetDataGridRows(Microsoft.Windows.Controls.DataGrid grid)
        {   
            var itemsSource = grid.ItemsSource as IEnumerable;
            if (null == itemsSource) yield return null;
            foreach (var item in itemsSource)
            {
                var row = grid.ItemContainerGenerator.ContainerFromItem(item) as Microsoft.Windows.Controls.DataGridRow;
                if (null != row) yield return row;
            }
        }

        private void dataGrid1_LoadingRow(object sender, DataGridRowEventArgs e)
        {
            //// Get the DataRow corresponding to the DataGridRow that is loading.
            //DataRowView item = e.Row.Item as DataRowView;
            //if (item != null)
            //{
            //    DataRow row = item.Row;

            //    // Access cell values values if needed...
            //    // var colValue = row["ColumnName1]";
            //    // var colValue2 = row["ColumName2]";

            //    // Set the background color of the DataGrid row based on whatever data you like from 
            //    // the row.
            //    //e.Row.Background = new SolidColorBrush(Colors.BlanchedAlmond);

                
                Random random = new Random(2);

                int rNumber = new Random().Next(800 + e.Row.GetIndex() * 11, 1200 + e.Row.GetIndex() * 12);
                if ((rNumber % 3) == 0)
                    e.Row.Foreground = new SolidColorBrush(Colors.Green);
                if ((rNumber % 3) == 1)
                    e.Row.Foreground = new SolidColorBrush(Colors.Red);

               

                    //if (e.Row.GetIndex() == 2) 
                    //    e.Row.Foreground = new SolidColorBrush(Colors.Red);

                    //if (e.Row.GetIndex() == 3)
                    //    e.Row.Foreground = new SolidColorBrush(Colors.Green);

            //    foreach (KeyValuePair<string, string> pair in _dataList)
            //    {
            //        if (pair.Key.Equals("LAST_PRICE") && row[pair.Key] != DBNull.Value)
            //        {
            //            if (Convert.ToDouble(row[pair.Key]) < Convert.ToDouble(pair.Value))
            //                e.Row.Foreground = new SolidColorBrush(Colors.Green);
            //            else
            //                e.Row.Foreground = new SolidColorBrush(Colors.Red);
            //            break;
            //        }
            //    }
            //}               
        }

        private void dataGrid1_TargetUpdated(object sender, DataTransferEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            #region Start Subscription

            try
            {
                CreateTickerList();
                CreateStructure();
                //this.dataGrid1.DataContext = _bData.Tables[0];
                this.dataGrid1.ItemsSource = _bData.Tables[0].DefaultView;
                //Microsoft.Windows.Controls.DataGridRow dataGridRowsaa = (Microsoft.Windows.Controls.DataGridRow)GetDataGridRows(this.dataGrid1);
                BindData();
                foreach (Microsoft.Windows.Controls.DataGridRow gridrow in GetDataGridRows(this.dataGrid1)) { }


                proxy.StartSubscription(0, securityList, FieldsList);
            }
            //catch (FaultException<MyFaultException> faultEx)
            //{
            //    SetControlPropertyValue(textBox1, "Text", "BBEx. " + faultEx.Detail.Reason + Environment.NewLine);
            //MessageBox.Show(String.Format("{0}\n\n" + "The following occured in {1}:\n{2}", connectionException.Detail.Reason, connectionException.Detail.Operation, connectionException.Detail.Details), "Connection problem");
            //}
            catch (Exception ex)
            {
                //SetControlPropertyValue(textBox1, "Text", ex.Message + Environment.NewLine);
            }

            #endregion
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            proxy.StopSubscription();
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
