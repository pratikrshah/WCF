﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MarketFeedServiceLibrary;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace TestConsoleHost
{
    class Program
    {
        static void Main(string[] args)
        {            

            #region Opening BloombergService
            ServiceHost Bloomberghost = null;
            try
            {
                Bloomberghost = new ServiceHost(typeof(BloombergService));
                Bloomberghost.Open();
                Console.WriteLine("The service is running and is listening on for BloombergService:");
                Console.WriteLine("Press any key to stop the services.");
            }
            catch (TimeoutException timeProblem)
            {
                Console.WriteLine(timeProblem.Message);
            }
            catch (CommunicationException commProblem)
            {
                Console.WriteLine(commProblem.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            #endregion

            Console.ReadKey();
            if (Bloomberghost != null)
                Bloomberghost.Close();
            
        }
    }
}
