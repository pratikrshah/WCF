﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;
using System.Collections;

using TestClient.BloombergServiceReference;
//using TestClient.BloombergServiceReference01;
using System.Reflection;
using System.Drawing.Drawing2D;


namespace TestClient
{
    public partial class BloombergFrm2 : Form
    {
        public DataSet _bData;
        public BloombergDataCallBack callback;
        public InstanceContext context;
        public BloombergServiceClient proxy = null;

        delegate void SetControlValueCallback(Control oControl, string propName, object propValue);
        delegate void VoidMethodDelegate();
        private Dictionary<string, string> _dataList = new Dictionary<string, string>();
        private ArrayList securityList = new ArrayList();
        private ArrayList FieldsList = new ArrayList();

        private void CreateTickerList()
        {
            securityList.Clear();
            string tickers = string.Empty;
            if (checkBox1.Checked)
                tickers = "IBM US Equity, MSFT US Equity,GOOG US Equity,INTC US Equity,ORCL US Equity,PFE US Equity";
            else
                tickers = txtTickers.Text;
                //tickers = "CH Equity,A US Equity,A2A IM Equity,AA US Equity,AABAR UH Equity,AACC US Equity,AAI US Equity,AAL LN Equity,AAPL US Equity,AAV CN Equity,AB1 GR Equity,AB1 GY Equity,ABB US Equity,ABBN VX Equity,ABC US Equity,ABD US Equity,ABG SM Equity,ABG US Equity,ABG 12 P23 Equity,ABK US Equity,ABT US Equity,ABX CN Equity,ABX US Equity,AC FP Equity,AC/A CN Equity,ACA FP Equity,ACE LN Equity,ACE US Equity,ACE+NL Equity,ACE+OL Equity,ACE/A CN Equity,ACF US Equity,ACGL US Equity,ACH US Equity,ACI US Equity,ACL US Equity,ACL+AH Equity,ACLS US Equity,ACPI US Equity,ACS+MH Equity,ACS+WH Equity,ACUS US Equity,ACXM US Equity,ACY NO Equity,ADCT US Equity,ADEN VX Equity,ADI US Equity,ADI+AY Equity,ADI+GF Equity,ADI+MX Equity,ADI+MY Equity,ADM US Equity,ADN LN Equity,ADP US Equity,ADPT US Equity,ADS GR Equity,ADS US Equity,AED Curncy,AEE US Equity,AEG SJ Equity,AEIS US Equity,AEL US Equity,AEM US Equity,AEP US Equity,AEPI US Equity,AERG US Equity,AES US Equity,AET US Equity,AF FP Equity,AFFX US Equity,AFG US Equity,AFID LI Equity,AFN CN Equity,AG-U CN Equity,AGA CN Equity,AGCO US Equity,AGEN US Equity,AGI CN Equity,AGI NO Equity,AGL IM Equity,AGL US Equity,AGN NA Equity,AGN US Equity,AGO US Equity,AGO+ME Equity,AGP US Equity,AGS LN Equity,AGYS US Equity,AHC US Equity,AHL US Equity,AHT GB Equity,AI FP Equity,AIG US Equity,AIG+QZ Equity,AIN US Equity,AIQ US Equity,AIR US Equity,AIZ US Equity,AJL+LV Equity,AJL+WV Equity,AJL+XV Equity,AKAM US Equity,AKR US Equity,AKS NO Equity,AKS US Equity,AKZA NA Equity,ALA-U CN Equity,ALBAV FH Equity,ALBK ID Equity,ALDAR UH Equity,ALF NZ Equity,ALK US Equity,ALKS US Equity,ALL US Equity,ALLN SW Equity,ALN US Equity,ALNBT FP Equity,ALOY US Equity,ALPRO FP Equity,ALSK US Equity,ALT FP Equity,ALU FP Equity,ALU US Equity,ALV GR Equity,ALV US Equity,ALXN US Equity,ALY US Equity,AM US Equity,AMCN US Equity,AMD US Equity,AMD+AA Equity,AMEC LN Equity,AMG US Equity,AMGN US Equity,AMIE US Equity,AMKR US Equity,AMLN US Equity,AMMD US Equity,AMQ+GJ Equity,AMQ+JJ Equity,AMR US Equity,AMS US Equity,AMT US Equity,AMZN US Equity,AN US Equity,AN+AV Equity,ANAD US Equity,ANF US Equity,ANG SJ Equity,ANH US Equity,ANN US Equity,ANO CN Equity,ANR US Equity,ANZ NZ Equity,AOB US Equity,AOI US Equity,AOIL SS Equity,APC US Equity,APOL US Equity,APU US Equity,APV+FJ Equity,APV+UN Equity,APV+VL Equity,APV+VN Equity,APV+WO Equity,APV+WP Equity,APWR US Equity,AQN CN Equity,AQP LN Equity,AQP SJ Equity,ARE CN Equity,ARE US Equity,ARE+JJ Equity,ARG US Equity,ARM US Equity,ARO GR Equity,ARRS US Equity,ARTC US Equity,ARW US Equity,ASA SJ Equity,ASCA US Equity,ASM NA Equity,ASMI US Equity,ASML NA Equity,ASML US Equity,ASX US Equity,ATA FP Equity,ATEC AV Equity,ATI US Equity,ATK US Equity,ATLN VX Equity,ATMI US Equity,ATML US Equity,ATO FP Equity,ATP CN Equity,ATPG US Equity,ATS Curncy,ATSI US Equity,ATU US Equity,AU CN Equity,AU US Equity,AUB FP Equity,AUD Curncy,AUDC US Equity,AUO US Equity,AURE FP Equity,AUY US Equity,AUY+GB Equity,AUY+GH Equity,AV US Equity,AV/ LN Equity,AVA US Equity,AVB US Equity,AVB+MR Equity,AVP US Equity,AVP US 1 C40 Equity,AVP US 1 P40 Equity,AVT US Equity,AVTR US Equity,AVY US Equity,AWI US Equity,AX-U CN Equity,AXE US Equity,AXL US Equity,AXP US Equity,AYE US Equity,AZN LN Equity,AZO US Equity,AZPN US Equity,B US Equity,B2I GR Equity,BA US Equity,BA/ LN Equity,BAC US Equity,BALN VX Equity,BAMA NA Equity,BANPU TB Equity,BARC LN Equity,BAS GR Equity,BAW SJ Equity,BAX US Equity,BAY LN Equity,BBA LN Equity,BBBB US Equity,BBD/B CN Equity,BBDC3 BZ Equity,BBG US Equity,BBI US Equity,BBVA SM Equity,BBY US Equity,BC US Equity,BCB CN Equity,BCI PM Equity,BCP PL Equity,BDC US Equity,BDK US Equity,BDN US Equity,BDTTZ US Equity,BDU+CB Equity,BDX US Equity,BDX+KO Equity,BDX+LO Equity,BEAT US Equity,BEAV US Equity,BEC US Equity,BEE US Equity,BEF Curncy,BEI GR Equity,BELM US Equity,BEN US Equity,BESI NA Equity,BG US Equity,BGC CN Equity,BGC US Equity,BGG US Equity,BGH TB Equity,BGY GB Equity,BHI US Equity,BHP US Equity,BHW PW Equity,BID US Equity,BIDU US Equity,BIIB US Equity,BIM IM Equity,BIO US Equity,BJN+XA Equity,BJS US Equity,BKI US Equity,BKMB OM Equity,BKS US Equity,BKUNQ US Equity,BLAND TB Equity,BLDR US Equity,BLK US Equity,BLL US Equity,BLND LN Equity,BLT LN Equity,BLT US Equity,BMC US Equity,BMD CN Equity,BMPS IM Equity,BMPS 12 C1.25 Equity,BMPS 12 C1.40 Equity,BMPS 12 C1.55 Equity,BMPS 12 P1.10 Equity,BMPS 12 P1.15 Equity,BMPS 12 P1.20 Equity,BMPS 12 P1.35 Equity,BMPS 12 P1.40 Equity,BMPS 12 P1.65 Equity,BMPS 3 C1.90 Equity,BMPS 3 P1.30 Equity,BMPS 3 P1.90 Equity,BMPS 4 P1.00 Equity,BMPS 6 C1.80 Equity,BMPS 6 C1.90 Equity,BMPS 6 P.90 Equity,BMPS 6 P1.15 Equity,BMPS 6 P1.90 Equity,BMPS 9 C1.20 Equity,BMPS 9 C1.25 Equity,BMPS 9 P1.05 Equity,BMPS 9 P1.15 Equity,BMPS 9 P1.20 Equity,BMPS IM 2 C1.25 Equity,BMPS IM 3 C1.35 Equity,BMPS IM 6 C1.25 Equity,BMPS IM 6 C1.35 Equity,BMPS IM 6 C1.40 Equity,BMPS IM 6 P1.40 Equity,BMPS IM 6 P1.80 Equity,BMPS IM 9 C1.25 Equity,BMPS IM 9 C1.30 Equity,BMPS IM 9 C1.35 Equity,BMR US Equity,BMRN US Equity,BMS US Equity,BMW GR Equity,BMY US Equity,BN FP Equity,BNE US Equity,BNI+LP Equity,BNP FP Equity,BNP-U CN Equity,BNQ+JD Equity,BNS IM Equity,BOC GA Equity,BONT US Equity,BP IM Equity,BP US Equity,BP/ LN Equity,BPA LN 3 C600 Equity,BPA LN 3 P520 Equity,BPA LN 3 P720 Equity,BPA LN 9 C680 Equity";//,BPA LN 9 P680 Equity,BPC CN Equity,BPE IM Equity,BPFH US Equity,BPO CN Equity,BRCD US Equity,BRCM US Equity,BRE US Equity,BRE-U CN Equity,BREB BB Equity,BRK-U CN Equity,BRK/B US Equity,BRKS US Equity,BRL Curncy,BRLUSD Curncy,BRS US Equity,BRTS IT Equity,BSC US Equity,BSKT US Equity,BSX US Equity,BSY LN Equity,BTE-U CN Equity,BTU US Equity,BTU+SN Equity,BTX GB Equity,BUD US Equity,BUL IM Equity,BUL IM 12 P6.60 Equity,BULL FP Equity,BVF US Equity,BVN US Equity,BWA US Equity,BWS US Equity,BXC US Equity,BXE CN Equity,BXG US Equity,BXP US Equity,BYD US Equity,BYO+AN Equity,BYO+AO Equity,BYO+AP Equity";
            
            securityList.AddRange(tickers.Split(new char[] { ',' }));
            for (int i = 0; i < securityList.Count; i++)
                securityList[i] = securityList[i].ToString().Trim();   

            ArrayList temp = new ArrayList();
            temp = ShuffleArrayList(securityList);
            securityList.Clear();
            securityList = temp;
                  
        }

        private ArrayList ShuffleArrayList(ArrayList source)
        {
            ArrayList sortedList = new ArrayList();
            Random generator = new Random();

            while (source.Count > 0)
            {
                int position = generator.Next(source.Count);
                sortedList.Add(source[position]);
                source.RemoveAt(position);
            }

            return sortedList;
        }

        public BloombergFrm2()
        {
            InitializeComponent();
        }

        private void BindData()
        {
            try
            {
                if (InvokeRequired)
                {
                    BeginInvoke(new VoidMethodDelegate(BindData));
                    return;
                }

                dataGridView1.SuspendLayout();
                int i = 0;
                foreach (DataRow row in _bData.Tables[0].Rows)
                {
                    if (_dataList.ContainsValue(row["TICKER"].ToString()))
                    {
                        foreach (KeyValuePair<string, string> pair in _dataList)
                        {
                            if (pair.Key.Equals("LAST_PRICE") && row[pair.Key] != DBNull.Value)
                            {
                                if (Convert.ToDouble(row[pair.Key]) < Convert.ToDouble(pair.Value))
                                    //dataGridView1[pair.Key,i].Style.ForeColor = Color.Green; 
                                    dataGridView1.Rows[i].DefaultCellStyle.ForeColor = Color.Green;
                                else
                                    //dataGridView1[pair.Key, i].Style.ForeColor = Color.Red;
                                    dataGridView1.Rows[i].DefaultCellStyle.ForeColor = Color.Red;
                            }
                            row[pair.Key] = pair.Value;
                        }
                        //row.AcceptChanges();
                    }
                    i++;
                }
                //if (_dataList.Count != 0) // First time bind
                //{
                //    dataGridView1.DataSource = _bData.Tables[0];
                //    //createGraphicsColumn();
                //}
                dataGridView1.ResumeLayout();
            }
            catch (Exception ex)
            {
                textBox1.Text += ex.Message + Environment.NewLine;
            }
        }

        private void btnStartSubscription_Click(object sender, EventArgs e)
        {
            try
            {
                CreateTickerList();
                CreateStructure();
                dataGridView1.DataSource = _bData.Tables[0];
                BindData();
                Application.DoEvents();

                proxy.StartSubscription(Convert.ToInt16(textBoxInterval.Text == string.Empty ? "5" : textBoxInterval.Text), securityList, FieldsList);
            }
            //catch (FaultException<MyFaultException> faultEx)
            //{
            //    SetControlPropertyValue(textBox1, "Text", "BBEx. " + faultEx.Detail.Reason + Environment.NewLine);
                //MessageBox.Show(String.Format("{0}\n\n" + "The following occured in {1}:\n{2}", connectionException.Detail.Reason, connectionException.Detail.Operation, connectionException.Detail.Details), "Connection problem");
            //}
            catch (Exception ex)
            {
                SetControlPropertyValue(textBox1, "Text", ex.Message + Environment.NewLine);
            }
        }

        private void BloombergFrm2_Load(object sender, EventArgs e)
        {
            string strFieldName = "LAST_PRICE,BID,ASK,PREV_CLOSE_VALUE_REALTIME,VOLUME";
            FieldsList.AddRange(strFieldName.Split(new char[] { ',' }));

            comboBoxFields.Items.AddRange(FieldsList.ToArray());
            comboBoxFields.SelectedIndex = 0;
            txtTickers.Text = "CH Equity,A US Equity,A2A IM Equity,AA US Equity,AABAR UH Equity,AACC US Equity,AAI US Equity,AAL LN Equity,AAPL US Equity,AAV CN Equity,AB1 GR Equity,AB1 GY Equity,ABB US Equity,ABBN VX Equity,ABC US Equity,ABD US Equity,ABG SM Equity,ABG US Equity,ABG 12 P23 Equity,ABK US Equity,ABT US Equity,ABX CN Equity,ABX US Equity,AC FP Equity,AC/A CN Equity,ACA FP Equity,ACE LN Equity,ACE US Equity,ACE+NL Equity,ACE+OL Equity,ACE/A CN Equity,ACF US Equity,ACGL US Equity,ACH US Equity,ACI US Equity,ACL US Equity,ACL+AH Equity,ACLS US Equity,ACPI US Equity,ACS+MH Equity,ACS+WH Equity,ACUS US Equity,ACXM US Equity,ACY NO Equity,ADCT US Equity,ADEN VX Equity,ADI US Equity,ADI+AY Equity,ADI+GF Equity,ADI+MX Equity,ADI+MY Equity,ADM US Equity,ADN LN Equity,ADP US Equity,ADPT US Equity,ADS GR Equity,ADS US Equity,AED Curncy,AEE US Equity,AEG SJ Equity,AEIS US Equity,AEL US Equity,AEM US Equity,AEP US Equity,AEPI US Equity,AERG US Equity,AES US Equity,AET US Equity,AF FP Equity,AFFX US Equity,AFG US Equity,AFID LI Equity,AFN CN Equity,AG-U CN Equity,AGA CN Equity,AGCO US Equity,AGEN US Equity,AGI CN Equity,AGI NO Equity,AGL IM Equity,AGL US Equity,AGN NA Equity,AGN US Equity,AGO US Equity,AGO+ME Equity,AGP US Equity,AGS LN Equity,AGYS US Equity,AHC US Equity,AHL US Equity,AHT GB Equity,AI FP Equity,AIG US Equity,AIG+QZ Equity,AIN US Equity,AIQ US Equity,AIR US Equity,AIZ US Equity,AJL+LV Equity,AJL+WV Equity,AJL+XV Equity,AKAM US Equity,AKR US Equity,AKS NO Equity,AKS US Equity,AKZA NA Equity,ALA-U CN Equity,ALBAV FH Equity,ALBK ID Equity,ALDAR UH Equity,ALF NZ Equity,ALK US Equity,ALKS US Equity,ALL US Equity,ALLN SW Equity,ALN US Equity,ALNBT FP Equity,ALOY US Equity,ALPRO FP Equity,ALSK US Equity,ALT FP Equity,ALU FP Equity,ALU US Equity,ALV GR Equity,ALV US Equity,ALXN US Equity,ALY US Equity,AM US Equity,AMCN US Equity,AMD US Equity,AMD+AA Equity,AMEC LN Equity,AMG US Equity,AMGN US Equity,AMIE US Equity,AMKR US Equity,AMLN US Equity,AMMD US Equity,AMQ+GJ Equity,AMQ+JJ Equity,AMR US Equity,AMS US Equity,AMT US Equity,AMZN US Equity,AN US Equity,AN+AV Equity,ANAD US Equity,ANF US Equity,ANG SJ Equity,ANH US Equity,ANN US Equity,ANO CN Equity,ANR US Equity,ANZ NZ Equity,AOB US Equity,AOI US Equity,AOIL SS Equity,APC US Equity,APOL US Equity,APU US Equity,APV+FJ Equity,APV+UN Equity,APV+VL Equity,APV+VN Equity,APV+WO Equity,APV+WP Equity,APWR US Equity,AQN CN Equity,AQP LN Equity,AQP SJ Equity,ARE CN Equity,ARE US Equity,ARE+JJ Equity,ARG US Equity,ARM US Equity,ARO GR Equity,ARRS US Equity,ARTC US Equity,ARW US Equity,ASA SJ Equity,ASCA US Equity,ASM NA Equity,ASMI US Equity,ASML NA Equity,ASML US Equity,ASX US Equity,ATA FP Equity,ATEC AV Equity,ATI US Equity,ATK US Equity,ATLN VX Equity,ATMI US Equity,ATML US Equity,ATO FP Equity,ATP CN Equity,ATPG US Equity,ATS Curncy,ATSI US Equity,ATU US Equity,AU CN Equity,AU US Equity,AUB FP Equity,AUD Curncy,AUDC US Equity,AUO US Equity,AURE FP Equity,AUY US Equity,AUY+GB Equity,AUY+GH Equity,AV US Equity,AV/ LN Equity,AVA US Equity,AVB US Equity,AVB+MR Equity,AVP US Equity,AVP US 1 C40 Equity,AVP US 1 P40 Equity,AVT US Equity,AVTR US Equity,AVY US Equity,AWI US Equity,AX-U CN Equity,AXE US Equity,AXL US Equity,AXP US Equity,AYE US Equity,AZN LN Equity,AZO US Equity,AZPN US Equity,B US Equity,B2I GR Equity,BA US Equity,BA/ LN Equity,BAC US Equity,BALN VX Equity,BAMA NA Equity,BANPU TB Equity,BARC LN Equity,BAS GR Equity,BAW SJ Equity,BAX US Equity,BAY LN Equity,BBA LN Equity,BBBB US Equity,BBD/B CN Equity,BBDC3 BZ Equity,BBG US Equity,BBI US Equity,BBVA SM Equity,BBY US Equity,BC US Equity,BCB CN Equity,BCI PM Equity,BCP PL Equity,BDC US Equity,BDK US Equity,BDN US Equity,BDTTZ US Equity,BDU+CB Equity,BDX US Equity,BDX+KO Equity,BDX+LO Equity,BEAT US Equity,BEAV US Equity,BEC US Equity,BEE US Equity,BEF Curncy,BEI GR Equity,BELM US Equity,BEN US Equity,BESI NA Equity,BG US Equity,BGC CN Equity,BGC US Equity,BGG US Equity,BGH TB Equity,BGY GB Equity,BHI US Equity,BHP US Equity,BHW PW Equity,BID US Equity,BIDU US Equity,BIIB US Equity,BIM IM Equity,BIO US Equity,BJN+XA Equity,BJS US Equity,BKI US Equity,BKMB OM Equity,BKS US Equity,BKUNQ US Equity,BLAND TB Equity,BLDR US Equity,BLK US Equity,BLL US Equity,BLND LN Equity,BLT LN Equity,BLT US Equity,BMC US Equity,BMD CN Equity,BMPS IM Equity,BMPS 12 C1.25 Equity,BMPS 12 C1.40 Equity,BMPS 12 C1.55 Equity,BMPS 12 P1.10 Equity,BMPS 12 P1.15 Equity,BMPS 12 P1.20 Equity,BMPS 12 P1.35 Equity,BMPS 12 P1.40 Equity,BMPS 12 P1.65 Equity,BMPS 3 C1.90 Equity,BMPS 3 P1.30 Equity,BMPS 3 P1.90 Equity,BMPS 4 P1.00 Equity,BMPS 6 C1.80 Equity,BMPS 6 C1.90 Equity,BMPS 6 P.90 Equity,BMPS 6 P1.15 Equity,BMPS 6 P1.90 Equity,BMPS 9 C1.20 Equity,BMPS 9 C1.25 Equity,BMPS 9 P1.05 Equity,BMPS 9 P1.15 Equity,BMPS 9 P1.20 Equity,BMPS IM 2 C1.25 Equity,BMPS IM 3 C1.35 Equity,BMPS IM 6 C1.25 Equity,BMPS IM 6 C1.35 Equity,BMPS IM 6 C1.40 Equity,BMPS IM 6 P1.40 Equity,BMPS IM 6 P1.80 Equity,BMPS IM 9 C1.25 Equity,BMPS IM 9 C1.30 Equity,BMPS IM 9 C1.35 Equity,BMR US Equity,BMRN US Equity,BMS US Equity,BMW GR Equity,BMY US Equity,BN FP Equity,BNE US Equity,BNI+LP Equity,BNP FP Equity,BNP-U CN Equity,BNQ+JD Equity,BNS IM Equity,BOC GA Equity,BONT US Equity,BP IM Equity,BP US Equity,BP/ LN Equity,BPA LN 3 C600 Equity,BPA LN 3 P520 Equity,BPA LN 3 P720 Equity,BPA LN 9 C680 Equity";//,BPA LN 9 P680 Equity,BPC CN Equity,BPE IM Equity,BPFH US Equity,BPO CN Equity,BRCD US Equity,BRCM US Equity,BRE US Equity,BRE-U CN Equity,BREB BB Equity,BRK-U CN Equity,BRK/B US Equity,BRKS US Equity,BRL Curncy,BRLUSD Curncy,BRS US Equity,BRTS IT Equity,BSC US Equity,BSKT US Equity,BSX US Equity,BSY LN Equity,BTE-U CN Equity,BTU US Equity,BTU+SN Equity,BTX GB Equity,BUD US Equity,BUL IM Equity,BUL IM 12 P6.60 Equity,BULL FP Equity,BVF US Equity,BVN US Equity,BWA US Equity,BWS US Equity,BXC US Equity,BXE CN Equity,BXG US Equity,BXP US Equity,BYD US Equity,BYO+AN Equity,BYO+AO Equity,BYO+AP Equity";
            //createGraphicsColumn();
            dataGridView1.DefaultCellStyle.BackColor = Color.Black;
            dataGridView1.DefaultCellStyle.ForeColor = Color.White;

            //proxy = new BloombergServiceClient("NetTcpBinding_IBloombergService");
            callback = new BloombergDataCallBack();
            context = new InstanceContext(callback);
            proxy = new BloombergServiceClient(context);

            proxy.IsMarketSimulator(true);

            if (callback != null)
                callback.UpdateReceived += new BloombergDataCallBack.BloombergEventHandler(callback_UpdateReceived_eventHandler);
        }

        private void callback_UpdateReceived_eventHandler(object sender, EventArgs e)
        {
            BloombergEventArgs args = (BloombergEventArgs)e;
            if (args.Source == SourceReceived.StatusReceived)
            {
                SetControlPropertyValue(textBox1, "Text", textBox1.Text + DateTime.Now + " - " + args.Message + Environment.NewLine);
            }
            else if (args.Source == SourceReceived.DataReceived)
            {
                _dataList = args.DataList;
                BindData();
            }
        }

        private void SetControlPropertyValue(Control oControl, string propName, object propValue)
        {
            if (oControl.InvokeRequired)
            {
                SetControlValueCallback d = new SetControlValueCallback(SetControlPropertyValue);
                oControl.BeginInvoke(d, new object[] { oControl, propName, propValue });
            }
            else
            {
                Type t = oControl.GetType();
                PropertyInfo[] props = t.GetProperties();
                foreach (PropertyInfo p in props)
                {
                    if (p.Name.ToUpper() == propName.ToUpper())
                    {
                        p.SetValue(oControl, propValue, null);
                    }
                }
            }
        }

        private void CreateStructure()
        {
            _bData = new DataSet();            
            DataTable dt = new DataTable();
            dt.Columns.Add("TICKER", typeof(string));
            for(int i = 0; i < FieldsList.Count; i++)
                dt.Columns.Add(FieldsList[i].ToString(), typeof(string));

            for (int i = 0; i < securityList.Count; i++)
            {
                object[] rowVals = new object[FieldsList.Count];
                rowVals[0] = securityList[i].ToString();  
                dt.Rows.Add(rowVals);
            }
            _bData.Tables.Add(dt);
        }

        private void btnStopSubscription_Click(object sender, EventArgs e)
        {
            proxy.StopSubscription();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            FieldsList.Add(txtFieldName.Text);
            comboBoxFields.Items.Clear();
            comboBoxFields.Items.AddRange(FieldsList.ToArray());
            txtFieldName.Text = string.Empty;
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            string item = comboBoxFields.SelectedItem.ToString();
            if (FieldsList.Contains(item))
                FieldsList.Remove(item);
            
            comboBoxFields.Items.Clear();
            comboBoxFields.Items.AddRange(FieldsList.ToArray());
            comboBoxFields.SelectedIndex = 0;
        }

        private void createGraphicsColumn()
        {
            Icon treeIcon = new Icon(this.GetType(), "Icon1.ico");
            DataGridViewImageColumn iconColumn = new DataGridViewImageColumn();
            iconColumn.Image = treeIcon.ToBitmap();
            iconColumn.Name = "Tree";
            iconColumn.HeaderText = "Nice tree";
            //dataGridView1.Columns.Insert(2, iconColumn);
            dataGridView1.Columns.Add(iconColumn);
        }

        private void dataGridView1_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            if (this.dataGridView1.Columns["BID"].Index == e.ColumnIndex && e.RowIndex >= 0)
            {
                //Rectangle newRectaa = new Rectangle(e.CellBounds.X + 1, e.CellBounds.Y + 1, e.CellBounds.Width - 4, e.CellBounds.Height - 4);
                //Graphics g = e.Graphics;
                //g.SmoothingMode = SmoothingMode.AntiAlias;
                //g.FillRectangle(Brushes.Transparent, newRectaa);                

                //Pen p = new Pen(Color.Red,5);
                //p.StartCap = LineCap.Round;
                //p.EndCap = LineCap.ArrowAnchor;
                //g.DrawLine(p, e.CellBounds.X + 1, e.CellBounds.Y + 1, e.CellBounds.Width, e.CellBounds.Height);   
                
                //p.Dispose();  

                #region Blue Box
                //Rectangle newRect = new Rectangle(e.CellBounds.X + 1, e.CellBounds.Y + 1, e.CellBounds.Width - 4, e.CellBounds.Height - 4);

                //using ( 
                //        Brush gridBrush = new SolidBrush(this.dataGridView1.GridColor),
                //        backColorBrush = new SolidBrush(e.CellStyle.BackColor)
                //      )
                //{
                //    using (Pen gridLinePen = new Pen(gridBrush))
                //    {
                //        // Erase the cell.
                //        e.Graphics.FillRectangle(backColorBrush, e.CellBounds);

                //        // Draw the grid lines (only the right and bottom lines;
                //        // DataGridView takes care of the others).
                //        e.Graphics.DrawLine(gridLinePen, e.CellBounds.Left,e.CellBounds.Bottom - 1, e.CellBounds.Right - 1, e.CellBounds.Bottom - 1);
                //        e.Graphics.DrawLine(gridLinePen, e.CellBounds.Right - 1,e.CellBounds.Top, e.CellBounds.Right - 1, e.CellBounds.Bottom);

                //        // Draw the inset highlight box.
                //        e.Graphics.DrawRectangle(Pens.Blue, newRect);

                //        // Draw the text content of the cell, ignoring alignment.
                //        if (e.Value != null && e.Value != DBNull.Value)
                //        {
                //            e.Graphics.DrawString((String)e.Value, e.CellStyle.Font,
                //                Brushes.Crimson, e.CellBounds.X + 2,
                //                e.CellBounds.Y + 2, StringFormat.GenericDefault);
                //        }
                //        e.Handled = true;
                //    }
                //}
                #endregion
            }
        }
        
    }
}
