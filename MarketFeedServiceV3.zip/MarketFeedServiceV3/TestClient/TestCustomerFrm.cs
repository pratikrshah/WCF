﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TestClient.MarketFeedServiceLibrary;

namespace TestClient
{
    public partial class TestCustomerFrm : Form
    {
        public TestCustomerFrm()
        {
            InitializeComponent();
        }

        private Customer[] customers = null;
        private MarketFeedServiceClient proxy = null;

        private void TestCustomerFrm_Load(object sender, EventArgs e)
        {
            proxy = new MarketFeedServiceClient("WSHttpBinding_IMarketFeedService");
        }

        private void btnListCustomer_Click(object sender, EventArgs e)
        {
            customers = proxy.ListCustomer();
            customerBindingSource.DataSource = customers;
            //customerDataGridView.DataSource = customers;
        }


    }
}
