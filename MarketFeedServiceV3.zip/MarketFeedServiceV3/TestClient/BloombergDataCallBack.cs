﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceModel;

namespace TestClient
{
    //[CallbackBehavior(UseSynchronizationContext = false)]
    public class BloombergDataCallBack : BloombergServiceReference.IBloombergServiceCallback
    {
        public delegate void BloombergEventHandler(object o, BloombergEventArgs args);
        public event BloombergEventHandler UpdateReceived;

        #region IBloombergServiceCallback Members

        public void UpdateStatus(string message)
        {
            BloombergEventArgs args = new BloombergEventArgs();
            args.Message = message;
            args.Source = SourceReceived.StatusReceived;
            if (UpdateReceived != null)            
                UpdateReceived(this, args);
        }

        public void UpdateBloombergData(Dictionary<string, string> bDataList)
        {
            BloombergEventArgs args = new BloombergEventArgs();
            args.Message = string.Empty;
            args.Source = SourceReceived.DataReceived;
            args.DataList = bDataList;
            if (UpdateReceived != null)
                UpdateReceived(this, args);
        }

        #endregion
    }

    public class BloombergEventArgs : EventArgs
    {
        private string msg;
        public string Message
        {
            get { return msg; }
            set { msg = value; }
        }

        private Dictionary<string,string> _datalist;
        public Dictionary<string, string> DataList
        {
            get { return _datalist; }
            set { _datalist = value; }
        }


        private SourceReceived _source;
        public SourceReceived Source
        {
            get { return _source; }
            set { _source = value; }
        }
    }

    public enum SourceReceived 
    { 
        StatusReceived,
        DataReceived
    }    
}
