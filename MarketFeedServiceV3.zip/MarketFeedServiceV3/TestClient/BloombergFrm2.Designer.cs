﻿namespace TestClient
{
    partial class BloombergFrm2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnStopSubscription = new System.Windows.Forms.Button();
            this.btnStartSubscription = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.textBoxInterval = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.txtFieldName = new System.Windows.Forms.TextBox();
            this.btnRemove = new System.Windows.Forms.Button();
            this.comboBoxFields = new System.Windows.Forms.ComboBox();
            this.txtTickers = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 77);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(1);
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(1047, 415);
            this.dataGridView1.TabIndex = 8;
            this.dataGridView1.CellPainting += new System.Windows.Forms.DataGridViewCellPaintingEventHandler(this.dataGridView1_CellPainting);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 500);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(1047, 236);
            this.textBox1.TabIndex = 7;
            // 
            // btnStopSubscription
            // 
            this.btnStopSubscription.Location = new System.Drawing.Point(180, 5);
            this.btnStopSubscription.Name = "btnStopSubscription";
            this.btnStopSubscription.Size = new System.Drawing.Size(148, 37);
            this.btnStopSubscription.TabIndex = 6;
            this.btnStopSubscription.Text = "Stop Subscription";
            this.btnStopSubscription.UseVisualStyleBackColor = true;
            this.btnStopSubscription.Click += new System.EventHandler(this.btnStopSubscription_Click);
            // 
            // btnStartSubscription
            // 
            this.btnStartSubscription.Location = new System.Drawing.Point(12, 5);
            this.btnStartSubscription.Name = "btnStartSubscription";
            this.btnStartSubscription.Size = new System.Drawing.Size(141, 37);
            this.btnStartSubscription.TabIndex = 5;
            this.btnStartSubscription.Text = "Start Subscription";
            this.btnStartSubscription.UseVisualStyleBackColor = true;
            this.btnStartSubscription.Click += new System.EventHandler(this.btnStartSubscription_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(1044, 12);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 9;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // textBoxInterval
            // 
            this.textBoxInterval.Location = new System.Drawing.Point(407, 9);
            this.textBoxInterval.Name = "textBoxInterval";
            this.textBoxInterval.Size = new System.Drawing.Size(51, 20);
            this.textBoxInterval.TabIndex = 10;
            this.textBoxInterval.Text = "5";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(360, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "interval";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(509, 9);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 12;
            this.btnAdd.Text = "Add Field";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // txtFieldName
            // 
            this.txtFieldName.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtFieldName.Location = new System.Drawing.Point(591, 12);
            this.txtFieldName.Name = "txtFieldName";
            this.txtFieldName.Size = new System.Drawing.Size(159, 20);
            this.txtFieldName.TabIndex = 13;
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(764, 10);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(97, 23);
            this.btnRemove.TabIndex = 14;
            this.btnRemove.Text = "Remove Field";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // comboBoxFields
            // 
            this.comboBoxFields.FormattingEnabled = true;
            this.comboBoxFields.Location = new System.Drawing.Point(866, 11);
            this.comboBoxFields.Name = "comboBoxFields";
            this.comboBoxFields.Size = new System.Drawing.Size(152, 21);
            this.comboBoxFields.TabIndex = 15;
            // 
            // txtTickers
            // 
            this.txtTickers.Location = new System.Drawing.Point(13, 46);
            this.txtTickers.Name = "txtTickers";
            this.txtTickers.Size = new System.Drawing.Size(1046, 20);
            this.txtTickers.TabIndex = 16;
            // 
            // BloombergFrm2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1096, 748);
            this.Controls.Add(this.txtTickers);
            this.Controls.Add(this.comboBoxFields);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.txtFieldName);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxInterval);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnStopSubscription);
            this.Controls.Add(this.btnStartSubscription);
            this.Name = "BloombergFrm2";
            this.Text = "BloombergFrm2";
            this.Load += new System.EventHandler(this.BloombergFrm2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnStopSubscription;
        private System.Windows.Forms.Button btnStartSubscription;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.TextBox textBoxInterval;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox txtFieldName;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.ComboBox comboBoxFields;
        private System.Windows.Forms.TextBox txtTickers;
    }
}